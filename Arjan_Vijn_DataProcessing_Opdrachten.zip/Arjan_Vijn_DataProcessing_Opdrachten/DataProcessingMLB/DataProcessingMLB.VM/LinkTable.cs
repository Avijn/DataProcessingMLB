﻿namespace DataProcessingMLB.VM
{
    public class LinkTable
    {
        public string team { get; set; }
        public string city { get; set; }
        public string nickName { get; set; }
        public string cityNickName { get; set; }
    }
}    
