﻿using System;
using System.Xml.Serialization;

namespace DataProcessingMLB.VM
{
    public class USCPIModel
    {
        public DateTime Yearmon { get; set; }
        public double CPI { get; set; }
    }
}
