﻿namespace DataProcessingMLB.VM
{
    public class BeerPriceObj
    {
        public int year { get; set; }
        public string team { get; set; }
        public string nickname { get; set; }
        public double price { get; set; }
        public double size { get; set; }
        public double price_per_Ounce { get; set; }
    }
}


