﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataProcessingMLB.VM
{
    public class Ranking
    {
        public int rank { get; set; }
        public string team { get; set; }
    }
}
